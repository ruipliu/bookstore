from django.contrib import admin
from books.models import Books
# Register your models here.
admin.site.register(Books)
