from django.contrib import admin
from users.models import Passport

admin.site.register(Passport)

# Register your models here.
