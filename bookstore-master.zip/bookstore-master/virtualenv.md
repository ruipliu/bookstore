1. 安装virtualenv

```
$ pip install virtualenv
```

2. 使用virtualenv新建虚拟环境

```
$ virtualenv -p python3 py3
```

3. 进入虚拟环境

```
$ source py3/bin/activate
```
